const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const db = require('./models/db'); // Import koneksi database
const authRoutes = require('./routes/auth');
const documentRoutes = require('./routes/documents');

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', './views');

// Session middleware
app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true
}));

// Route
app.use('/', authRoutes);
app.use('/documents', documentRoutes);

// Route utama
app.get('/', (req, res) => {
    res.render('index'); // Halaman utama
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
