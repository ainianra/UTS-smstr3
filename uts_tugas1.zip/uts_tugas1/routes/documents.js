const express = require('express');
const db = require('../models/db');
const router = express.Router();
const app = express();
const path = require('path');

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Middleware untuk memastikan user sudah login
function isAuthenticated(req, res, next) {
    if (req.session.userId) {
        return next();
    }
    res.redirect('/login');
}

// Dashboard
router.get('/', isAuthenticated, (req, res) => {
    db.query('SELECT * FROM documents WHERE user_id = ?', [req.session.userId], (error, results) => {
        if (error) {
            console.error("Error fetching documents:", error);
            return res.status(500).render('error', { message: 'Error fetching documents.' });
        }
        res.render('documents', { documents: results });
    });
});

// Tambah dokumen
router.post('/add', isAuthenticated, (req, res) => {
    const { document_type, document_number, expiration_date } = req.body;
    db.query('INSERT INTO documents (user_id, document_type, document_number, expiration_date) VALUES (?, ?, ?, ?)', 
        [req.session.userId, document_type, document_number, expiration_date], (error) => {
            if (error) {
                console.error("Error adding document:", error);
                return res.status(500).render('error', { message: 'Error adding document.' });
            }
            res.redirect('/documents');
    });
});

// Edit dokumen
router.get('/edit/:id', isAuthenticated, (req, res) => {
    const docId = req.params.id;
    db.query('SELECT * FROM documents WHERE id = ? AND user_id = ?', [docId, req.session.userId], (error, results) => {
        if (error) {
            console.error("Error fetching document for edit:", error);
            return res.status(500).render('error', { message: 'Error fetching document for edit.' });
        }
        if (results.length > 0) {
            res.render('edit', { document: results[0] });
        } else {
            res.status(404).render('error', { message: 'Document not found.' });
        }
    });
});

// Update dokumen
router.post('/update/:id', isAuthenticated, (req, res) => {
    const docId = req.params.id;
    const { document_type, document_number, expiration_date } = req.body;
    const query = 'UPDATE documents SET document_type = ?, document_number = ?, expiration_date = ? WHERE id = ? AND user_id = ?';
    
    db.query(query, [document_type, document_number, expiration_date, docId, req.session.userId], (error) => {
        if (error) {
            console.error("Error updating document:", error);
            return res.status(500).render('error', { message: 'Error updating document.' });
        }
        res.redirect('/documents');
    });
});

// Hapus dokumen
router.post('/delete/:id', isAuthenticated, (req, res) => {
    const docId = req.params.id;
    db.query('DELETE FROM documents WHERE id = ? AND user_id = ?', [docId, req.session.userId], (error) => {
        if (error) {
            console.error("Error deleting document:", error);
            return res.status(500).render('error', { message: 'Error deleting document.' });
        }
        res.redirect('/documents');
    });
});

module.exports = router;
