const express = require('express');
const bcrypt = require('bcrypt');
const db = require('../models/db');
const router = express.Router();
const app = express();
const path = require('path');

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Registrasi
router.get('/register', (req, res) => {
    res.render('register');
});

router.post('/register', (req, res) => {
    const { username, password, email } = req.body;
    bcrypt.hash(password, 10, (err, hash) => {
        if (err) throw err;
        db.query('INSERT INTO users (username, password, email) VALUES (?, ?, ?)', [username, hash, email], (error, results) => {
            if (error) throw error;
            res.redirect('/login');
        });
    });
});

// Login
router.get('/login', (req, res) => {
    res.render('login');
});

router.post('/login', (req, res) => {
    const { username, password } = req.body;
    db.query('SELECT * FROM users WHERE username = ?', [username], (error, results) => {
        if (results.length > 0) {
            bcrypt.compare(password, results[0].password, (err, match) => {
                if (match) {
                    req.session.userId = results[0].id; // Simpan user id ke session
                    return res.redirect('/documents');
                }
                res.send('Password is incorrect');
            });
        } else {
            res.send('User not found');
        }
    });
});

// Logout
router.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) throw err;
        res.redirect('/');
    });
});

module.exports = router;
