const mysql = require('mysql');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // ganti dengan username database
    password: '', // ganti dengan password database
    database: 'ppdp' // ganti dengan nama database yang telah dibuat
});

db.connect(err => {
    if (err) {
        console.error('Database connection failed:', err.stack);
        return;
    }
    console.log('Connected to database.');
});

module.exports = db;
