const nodemailer = require('nodemailer');

// Fungsi untuk mengirim email
const sendEmail = (to, subject, text) => {
    // Buat transporter untuk mengirim email
    const transporter = nodemailer.createTransport({
        service: 'gmail', // atau penyedia email lainnya
        auth: {
            user: 'aini.anra@gmail.com', // Ganti dengan email kamu
            pass: 'Anggrek3' // Ganti dengan password email kamu
        }
    });

    const mailOptions = {
        from: 'aini.anra@gmail.com', // Ganti dengan email kamu
        to: to,
        subject: subject,
        text: text
    };

    // Kirim email
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            return console.log('Error sending email: ', error);
        }
        console.log('Email sent: ' + info.response);
    });
};

module.exports = sendEmail;
